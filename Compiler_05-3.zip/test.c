int k = 3;

int add(int x, int y) {
	int z ;

	z = x+y;
	return z;
}

void incK(int a)
{
	k = k + 1;
	return;
}

double doubleadd(double a, double b)
{
	double temp;
	double aa = 1.123;
	temp = a + b;
	return temp;

}

void loop() {
	int a = 0;
	while (a < 100) {
		a++;
	}
}

void main () {
	int t = 33;
	incK(k);
	//double d = 345;
	_print(add(1,t));
	_print(doubleAdd(32, d))
}
