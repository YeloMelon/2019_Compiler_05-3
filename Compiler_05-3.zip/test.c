void main () {
	double a= 1.52;
	float b = 1.22;

	for (int i = 0; i < 100; i++) {
		a = 0;
	}
	_print(a + k);

