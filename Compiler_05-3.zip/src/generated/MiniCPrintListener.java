package generated;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.antlr.v4.runtime.ParserRuleContext;
import generated.*;

public class MiniCPrintListener extends MiniCBaseListener {

	//4space indentation
	private final String SPACE = "....";

	//line content 
	ParseTreeProperty<String> newTexts = new ParseTreeProperty<String>();
	//start at top
	private int depth = 0;
	//expect no else
	private boolean braceForElse = false;
	
	private String whileBracketStmt(MiniCParser.While_stmtContext ctx) {
		return new StringBuilder()
				.append("\n" + indent(true) + "{\n")
				//....{
				.append(indent(false) + newTexts.get(ctx.stmt()))
				//content inside brackets
				.append("\n" + indent(true) + "}")
				//....}
				.toString();
	}

	private String ifBracketStmt(MiniCParser.If_stmtContext ctx, int stmtIndex) {
		return new StringBuilder()
				.append("\n" + indent(true) + "{\n")
				//....{
				.append(indent(false) + newTexts.get(ctx.stmt(stmtIndex)))
				//content inside brackets
				.append("\n" + indent(true) + "}")
				//....}
				.toString();
	}
	
	private boolean isElseCompoundStmt(MiniCParser.If_stmtContext ctx) {
		//if ( blah ) { blah } else { blah } 
		//since if part is 6 tokens , if the compound stmt is else, the whole tokens should be more than 6
		return (ctx.getChildCount() > 6)
				
				&& (ctx.stmt(0).compound_stmt() == null) 
				
				&& (ctx.stmt(1).compound_stmt() != null);
	}

	private boolean isBinaryOperation(MiniCParser.ExprContext ctx) {
		//3 tokens
		return (ctx.getChildCount() == 3) 
				//& the token in the middle is an operator
				&& (ctx.getChild(1) != ctx.expr());
	}

	private boolean isPrefixOperation(MiniCParser.ExprContext ctx) {
		// only two tokens -> operator + expr 
		return (ctx.getChildCount() == 2);
	}

	private boolean isAssignmentOperation(MiniCParser.ExprContext ctx) {
		//3 tokens
		return (ctx.getChildCount() == 3) 
				//the token in the middle is '='
				&& (ctx.getChild(1).getText().equals("="));
	}

	private boolean isParenOperation(MiniCParser.ExprContext ctx) {
		//first token = '('
		return (ctx.getChild(0).getText().equals("("))
				//last token = ')'
				&& (ctx.getChild(2).getText().equals(")"));
	}

	private boolean isArrayOperation(MiniCParser.ExprContext ctx) {
		// a [ blah ] -> 4 tokens
		return (ctx.getChildCount() == 4)
				// array
				&& (ctx.getChild(1).getText().equals("["))
				&& (ctx.getChild(3).getText().equals("]"));
	}

	private boolean isFunctionOperation(MiniCParser.ExprContext ctx) {
		//foo( blah ) - > 4 tokens
		return (ctx.getChildCount() == 4)
				//function
				&& (ctx.getChild(1).getText().equals("("))
				&& (ctx.getChild(3).getText().equals(")"));
	}

	private boolean isArrayAssignmentOperation(MiniCParser.ExprContext ctx) {
		// a [ blah ] = blah -> 6tokens
		return (ctx.getChildCount() == 6)
				&& (ctx.getChild(4).getText().equals("="));
	}

	private String indent(boolean bracket) {
		StringBuilder code = new StringBuilder();
		// for every increase in depth, add another 4 dots ....
		for (int depth = 1; depth < this.depth; depth++)
			code.append(SPACE);
		//if inside a bracket, add another 4 spaces ....
		code.append(bracket ? "" : SPACE);
		
		return code.toString();
	}

	private void appendCode(int option, StringBuilder code, ParserRuleContext ctx, int start, int end) {
		// method for appending tokens with spaces in 
		switch (option) {
		//option 0 : first token
		case 0:
			while (start <= end)
				code.append(ctx.getChild(start++).getText());
			return;
		//append token to code with one space in front
		case 1:
			while (start <= end)
				code.append(" " + ctx.getChild(start++).getText());
			return;
		//append token to code with one space in back 
		case 2:
			while (start <= end)
				code.append(ctx.getChild(start++).getText() + " ");
			return;
		//append token to code with one space in back while last token appends finally, which means to the end	
		case 3:
			while (start <= end - 1)
				code.append(ctx.getChild(start++).getText() + " ");
			code.append(ctx.getChild(start).getText());
			return;
		// append code with 1 space in back of tokens except the last two
	
		case 4:
			while (start <= end - 2)
				code.append(ctx.getChild(start++).getText() + " ");
			code.append(ctx.getChild(start++).getText());
			code.append(ctx.getChild(start).getText());
			return;
		default:
			return;
		}
	}
	@Override 
	public void enterProgram(MiniCParser.ProgramContext ctx) { 
		//enter program
	}
	
	@Override 
	public void exitProgram(MiniCParser.ProgramContext ctx) { 
		StringBuilder newCode = new StringBuilder();
		
		for (int index = 0, count = ctx.getChildCount(); index < count; index++)
			// append everything with new line on every new text ( declaratives & functions)
			newCode.append(newTexts.get(ctx.getChild(index)) + "\n");
		System.out.print(newCode.toString());
	}
	
	@Override 
	public void enterDecl(MiniCParser.DeclContext ctx) { 
		//enter declaration
	}

	@Override 
	public void exitDecl(MiniCParser.DeclContext ctx) { 
		newTexts.put(ctx, newTexts.get(ctx.getChild(0)));
	}

	@Override 
	public void enterVar_decl(MiniCParser.Var_declContext ctx) { 
		//enter variable declaration
	}

	@Override 
	public void exitVar_decl(MiniCParser.Var_declContext ctx) { 
		StringBuilder code = new StringBuilder();
		int childCount = ctx.getChildCount() - 1;

		//not array declaration int i = blah ; : 4 at best
		if (childCount < 5) {
			appendCode(4, code, ctx, 0, childCount);
		}
		//array declaration int min [ 3 ] = x; : 7
		//int min [ 3 ] ; : 5
		else {
			//for the int min part i need a space so option 3 is called
			appendCode(3, code, ctx, 0, 1);
			//for the min[3] part, i dont need space so option 0 is called
			appendCode(0, code, ctx, 2, childCount);
		}
		//replace code variable declaration text to text with
		//appropriate spaces
		newTexts.put(ctx, code.toString());
	}

	@Override 
	public void enterType_spec(MiniCParser.Type_specContext ctx) {
		//enter type specs
	}
	
	@Override 
	public void exitType_spec(MiniCParser.Type_specContext ctx) {
		//using put, replace text with input
		newTexts.put(ctx, ctx.getText());
	}

	@Override 
	public void enterFun_decl(MiniCParser.Fun_declContext ctx) { 
		//enter function declaration
	}

	@Override 
	public void exitFun_decl(MiniCParser.Fun_declContext ctx) {
		//replace function text to be pretty
		newTexts.put(ctx, new StringBuilder()
				//type + space int func()
				.append(ctx.type_spec().getText() + " ")
				//append function name
				.append(ctx.IDENT().getText())
				// append (
				.append(ctx.getChild(2).getText())
				// append params
				.append(newTexts.get(ctx.params()))
				//append )
				.append(ctx.getChild(4).getText())
				//append { }part of func
				.append(newTexts.get(ctx.compound_stmt()))
				.toString());
	}

	@Override 
	public void enterParams(MiniCParser.ParamsContext ctx) { 
		//enter paratmeters
	}

	@Override 
	public void exitParams(MiniCParser.ParamsContext ctx) {
		StringBuilder code = new StringBuilder();
		int childCount = ctx.getChildCount() - 1;
		//more than one parameters
		if (childCount >= 1) {
			//append first parameter
			code.append(newTexts.get(ctx.param(0)));
			//add ', ' with following parameters
			for (int index = 1, params = ctx.param().size(); index < params; index++)
				code.append(", " + newTexts.get(ctx.param(index)));
		}
		//only one parameter
		else
			//just append code with no spaces
			appendCode(0, code, ctx, 0, childCount);

		newTexts.put(ctx, code.toString());
	}

	@Override 
	public void enterParam(MiniCParser.ParamContext ctx) { 
		//enter each parameter
	}

	@Override 
	public void exitParam(MiniCParser.ParamContext ctx) {
		//append type with one space : int func
		StringBuilder code = new StringBuilder(newTexts.get(ctx.type_spec()) + " ");
		//append the rest with no spaces in between : func(void)
		for (int index = 1, childCount = ctx.getChildCount(); index < childCount; index++)
			code.append(ctx.getChild(index).getText());
		newTexts.put(ctx, code.toString());
	}

	@Override 
	public void enterStmt(MiniCParser.StmtContext ctx) { 
		//enter statements
	}
	
	@Override 
	public void exitStmt(MiniCParser.StmtContext ctx) {
		//divide statements using enter & exit stmt
		newTexts.put(ctx, newTexts.get(ctx.getChild(0)));
	}

	@Override 
	public void enterExpr_stmt(MiniCParser.Expr_stmtContext ctx) {
		//enter expression statement
	}

	@Override 
	public void exitExpr_stmt(MiniCParser.Expr_stmtContext ctx) {
		//is expr_stmt
		newTexts.put(ctx, new StringBuilder()
				//append the expression
				.append(newTexts.get(ctx.expr()))
				//append semicolon ;
				.append(ctx.getChild(1).getText())
				.toString());
	}

	@Override 
	public void enterWhile_stmt(MiniCParser.While_stmtContext ctx) {
		//enter while statement
		//add a layer of depth for each compound statement block
		//for indentation
		if (ctx.stmt().compound_stmt() == null)
			depth++;
	}

	@Override 
	public void exitWhile_stmt(MiniCParser.While_stmtContext ctx) { 
		
		newTexts.put(ctx, new StringBuilder()
				//append while
				.append(ctx.getChild(0).getText())
				// ( 
				.append(ctx.getChild(1).getText())
				// append condition of while
				.append(newTexts.get(ctx.expr()))
				// append )
				.append(ctx.getChild(3).getText())
				// append {} stmt
				//using whileBracketStmt(), 
				.append(ctx.stmt().compound_stmt() == null ? whileBracketStmt(ctx) : newTexts.get(ctx.stmt()))
				.toString());

		//exit while indentation
		if (ctx.stmt().compound_stmt() == null)
			depth--;
	}

	@Override 
	public void enterCompound_stmt(MiniCParser.Compound_stmtContext ctx) {
		//enter bracketed statement
		//add indentation for each compound statement
		if (!braceForElse)
			depth++;
	}

	@Override 
	public void exitCompound_stmt(MiniCParser.Compound_stmtContext ctx) {
		StringBuilder code = new StringBuilder();

		// start at next line , add {, goto next line
		//inside bracket so insert indent
		code.append("\n" + indent(true) + ctx.getChild(0).getText() + "\n");
		// append local declaratives
		for (int index = 0, decls = ctx.local_decl().size(); index < decls; index++)
			code.append(indent(false) + newTexts.get(ctx.local_decl(index)) + "\n");
		//append statements
		for (int index = 0, stmts = ctx.stmt().size(); index < stmts; index++)
			code.append(indent(false) + newTexts.get(ctx.stmt(index)) + "\n");
		//append }
		code.append(indent(true) + ctx.getChild(ctx.getChildCount() - 1).getText());

		//if no braces for else statement, return to normal depth
		if (!braceForElse)
			depth--;
		
		newTexts.put(ctx, code.toString());
	}

	@Override 
	public void enterLocal_decl(MiniCParser.Local_declContext ctx) { 
		//enter local declarations
	}

	@Override 
	public void exitLocal_decl(MiniCParser.Local_declContext ctx) {
		StringBuilder code = new StringBuilder();
		int childCount = ctx.getChildCount() - 1;

		//not a array declaration
		if (childCount < 5)
			appendCode(4, code, ctx, 0, childCount);
		//array declaration 
		else {
			appendCode(3, code, ctx, 0, 1);
			appendCode(0, code, ctx, 2, childCount);
		}

		newTexts.put(ctx, code.toString());
	}

	@Override 
	public void enterIf_stmt(MiniCParser.If_stmtContext ctx) {
		//enter if statement
		//add indent
		if (ctx.stmt(0).compound_stmt() == null)
			depth++;
		//expect a brace for else
		if (isElseCompoundStmt(ctx))
			braceForElse = true;
	}

	@Override 
	public void exitIf_stmt(MiniCParser.If_stmtContext ctx) {
		StringBuilder code = new StringBuilder();

		//no else
		//if ( blah ) blah else blah : 7 tokens
		if (ctx.getChildCount() < 7) {
			//if
			code.append(ctx.getChild(0).getText())
			//(
				.append(ctx.getChild(1).getText())
				//binary expression
				.append(newTexts.get(ctx.expr()))
				//)
				.append(ctx.getChild(3).getText())
				//append bracket statement if there is one
				.append(ctx.stmt(0).compound_stmt() == null ? ifBracketStmt(ctx, 0) : newTexts.get(ctx.stmt(0)));
		} 
		//has else
		else {
			//if
			code.append(ctx.getChild(0).getText())
			//(
				.append(ctx.getChild(1).getText())
				// expression
				.append(newTexts.get(ctx.expr()))
				//)
				.append(ctx.getChild(3).getText())
				//append bracket statement if there is one
				.append(ctx.stmt(0).compound_stmt() == null ? ifBracketStmt(ctx, 0) : newTexts.get(ctx.stmt(0)));


			//add depth for bracket statement
			if (ctx.stmt(0).compound_stmt() != null)
				depth++;
			//else and an indent for else
			code.append("\n" + indent(true) + ctx.getChild(5).getText())
			//append second cmpd stmt 
				.append(ctx.stmt(1).compound_stmt() == null ? ifBracketStmt(ctx, 1) : newTexts.get(ctx.stmt(1)));
			
			//else is finished return boolean value to false
			if (isElseCompoundStmt(ctx))
				braceForElse = false;
			//return to normal depth if finished
			if (ctx.stmt(0).compound_stmt() != null)
				depth--;
		}
		//no cmpd stmt left, return to normal depth
		if (ctx.stmt(0).compound_stmt() == null)
			depth--;
		
		newTexts.put(ctx, code.toString());
	}

	@Override 
	public void enterReturn_stmt(MiniCParser.Return_stmtContext ctx) { 
		//enter return statement
	}

	@Override 
	public void exitReturn_stmt(MiniCParser.Return_stmtContext ctx) {
		newTexts.put(ctx, 
				//if only 2 tokens, its return;
				(ctx.getChildCount() == 2)
				//done;
				? ctx.getChild(0).getText() + ctx.getChild(1).getText()
				//else, its return blah;
				//so add space and blah
				: ctx.getChild(0).getText() + " " + newTexts.get(ctx.expr()) + ctx.getChild(2).getText());
	}

	@Override 
	public void enterExpr(MiniCParser.ExprContext ctx) { 
		//enter expression
	}

	@Override 
	public void exitExpr(MiniCParser.ExprContext ctx) { 
		StringBuilder code = new StringBuilder();
		//i = 2;
		if (isAssignmentOperation(ctx)) {
		//i 
			code.append(ctx.getChild(0).getText() + " ")
			// i =
				.append(ctx.getChild(1).getText() + " ")
				//i = 2;=
				.append(newTexts.get(ctx.expr(0)));
		} 
		//i / 2;
		else if (isBinaryOperation(ctx)) {
			//i
			code.append(newTexts.get(ctx.expr(0)) + " ")
			//i /
				.append(ctx.getChild(1).getText() + " ")
				//i / 2
				.append(newTexts.get(ctx.expr(1)));
		} 
		else if (isPrefixOperation(ctx)) {
		//i++ or ++1
			code.append(ctx.getChild(0).getText())
			//just append the two
				.append(newTexts.get(ctx.expr(0)));
		} 
		else if (isParenOperation(ctx)) {
			//(
			code.append(ctx.getChild(0).getText())
			//content
				.append(newTexts.get(ctx.expr(0)))
				//)
				.append(ctx.getChild(2).getText());
		} 
		else if (isArrayOperation(ctx)) {
			//min
			code.append(ctx.getChild(0).getText())
			//min[
				.append(ctx.getChild(1).getText())
				//min[3
				.append(newTexts.get(ctx.expr(0)))
				//min[3]
				.append(ctx.getChild(3).getText());
		} 
		else if (isFunctionOperation(ctx)) {
			//func
			code.append(ctx.getChild(0).getText())
			//func(
				.append(ctx.getChild(1).getText())
				//func(a
				.append(newTexts.get(ctx.args()))
				//func(a)
				.append(ctx.getChild(3).getText());
		} 
		else if (isArrayAssignmentOperation(ctx)) {
			//min
			code.append(ctx.getChild(0).getText())
			//min[
				.append(ctx.getChild(1).getText())
				//min[1
				.append(newTexts.get(ctx.expr(0)))
				//min[1].
				.append(ctx.getChild(3).getText() + " ")
				//min[1].=.
				.append(ctx.getChild(4).getText() + " ")
				//min[1].=.3
				.append(newTexts.get(ctx.expr(1)));
		} 
		else if (ctx.getChildCount() == 1)
		
			code.append(ctx.getText());
		
		newTexts.put(ctx, code.toString());
	}

	@Override 
	public void enterArgs(MiniCParser.ArgsContext ctx) {
		//enter arguments
	}

	@Override 
	public void exitArgs(MiniCParser.ArgsContext ctx) {
		StringBuilder code = new StringBuilder();
		
		int childCount = ctx.getChildCount() - 1;
		//more than 1 args
		if (childCount >= 1) {
			//append first one
			code.append(newTexts.get(ctx.expr(0)));
			//append next ones with ', ' in front of it
			for (int index = 1, args = ctx.expr().size(); index < args; index++)
				code.append(", " + newTexts.get(ctx.expr(index)));
		} else
			//1 args
			//(args)
			//option 0 for no space between
			appendCode(0, code, ctx, 0, childCount);

		newTexts.put(ctx, code.toString());
	}

	@Override 
	public void enterEveryRule(ParserRuleContext ctx) {

	}

	@Override 
	public void exitEveryRule(ParserRuleContext ctx) { 
		
	}

	@Override 
	public void visitTerminal(TerminalNode node) {

	}

	@Override 
	public void visitErrorNode(ErrorNode node) { 

	}
}